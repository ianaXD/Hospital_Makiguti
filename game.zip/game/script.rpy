﻿
define f = Character("Nanda")
define e = Character("Elaine")
define c = Character("Fernanda")

image fernanda normal = "images/fernanda_normal.png"
image fundo = "images/fundo.png"
image cleide = "fernanda_sorriso.png"

# The game starts here.

label start:

    scene fundo
    "BEM-VINDO ao TREINAMENTO do HOSPITAL MAKIGUTI"
    "Como nova estagiária do curso de gerência em saúde, você estará conhecendo os setores após a entrega da documentação."

    scene bg hospital_entrada
    show nanda_normal at left
    with fade
    f "Olá! Eu sou a Fernanda Carvalho, e eu trabalho no setor administrativo."
    f "Vou apresentar os principais colaboradores do hospital e explicar um pouco sobre pacientes envolvidos com sua própria segurança."

    show elaine_normal at right
    with dissolve
    e "Olá! Eu sou a Elaine, chefe da enfermagem e vou falar sobre cirurgia segura."
    f "No hospital, a sua segurança como paciente, e dos que você está cuidando, depende da atenção de todos."
    f "Vamos começar por aí."

    # Nanda explica Pacientes e Segurança
    e "Pacientes que participam ativamente do processo de segurança são menos propensos a erros."

    scene bg hospital_entrada
    show nanda_pensativa
    with dissolve
    f "Por exemplo, sempre confira seu nome e procedimento."

    scene bg hospital_entrada
    show nanda_sorriso
    with dissolve
    f "Agora que você sabe esses conceitos, vamos conhecer a Fernanda, minha xará."

    scene bg laboratorio with fade
    show fernanda_normal at left
    with dissolve
    c "Oi, sou Fernanda Cleide, técnica em análises clínicas. Trabalho no laboratório."
    c "Vou explicar um pouco sobre sangue e hemocomponentes e como administrar de forma segura."

    show fernanda_normal at left
    with dissolve
    c "Hemocomponentes são partes do sangue que podem ser transfundidas para pacientes, como hemácias e plaquetas."
    c "A segurança na administração inclui confirmar o sangue correto, a identidade do paciente e monitorar reações."

    scene bg laboratorio with fade
    show fernanda_explicando
    with dissolve
    c "Erro nessa etapa pode causar complicações graves."

    scene bg laboratorio with fade
    show fernanda_sorriso
    with dissolve
    c "Por isso, profissionais devem seguir protocolos rigorosos!"

    scene bg enfermaria with fade
    show elaine_normal at right
    with dissolve
    e "A segurança na cirurgia depende de seguir a checklist da OMS e confirmar vários passos antes, durante e após o procedimento."

    scene bg enfermaria with fade
    show elaine_pensativa
    with dissolve
    e "Confirmar o nome do paciente, identificar o local da cirurgia e garantir a esterilização dos instrumentos são cruciais."

    scene bg enfermaria2 with fade
    show elaine_alegre
    with dissolve
    e "Agora vamos ver se você entendeu tudo! Prepare-se para o quiz."

    # Quiz com 7 perguntas
    $ score = 0

    label quiz1:
        e "Pergunta 1: Qual informação devemos confirmar antes de administrar um hemocomponente?"
        menu:
            "Nome do paciente":
                $ score += 1
                e "Correto! A identificação é a prioridade."
            "Pressão arterial":
                $ score -= 0
                e "Não. Embora importante, não é o primeiro passo de segurança."

        e "Pergunta 2: Quem no hospital pode ajudar a garantir a segurança do paciente durante a transfusão?"
        menu:
            "Só o médico":
                $ score -= 0
                e "Errado! É uma responsabilidade de toda a equipe."
            "Toda a equipe de saúde":
                $ score += 1
                e "Certo! Toda equipe trabalha junta."

        e "Pergunta 3: O que deve ser feito antes do início de uma cirurgia?"
        menu:
            "Verificar a pulseira do paciente e o local da cirurgia":
                $ score += 1
                e "Certíssimo!"
            "Dar medicação calmante":
                $ score -=0
                e "Não é o procedimento inicial de segurança."

        e "Pergunta 4: Como evitar infecção durante a manipulação de hemocomponentes?"
        menu:
            "Usando luvas e materiais esterilizados":
                $ score += 1
                e "Exato!"
            "Não precisa usar luvas se só estiver olhando":
                $ score -= 0
                e "Errado, risco alto de contaminação."

        e "Pergunta 5: Quem é responsável por checar a documentação do paciente antes da cirurgia?"
        menu:
            "Enfermeira chefe":
                $ score += 1
                e "Muito bem! Esse é um papel importante da enfermagem."
            "Só o médico cirurgião":
                $ score -= 0
                e "Errado, a responsabilidade é compartilhada."

        e "Pergunta 6: O que é fundamental na comunicação para segurança do paciente?"
        menu:
            "Comunicação clara entre os profissionais":
                $ score += 1
                e "Muito bom!"
            "Passar a informação uma vez só":
                $ score -= 0
                e "Errado, é preciso confirmação constante."

        e "Pergunta 7: O que é o mais importante para o paciente se envolver na sua segurança?"
        menu:
            "Perguntar e conferir suas informações":
                $ score += 1
                e "Exatamente!"
            "Deixar tudo com os profissionais":
                $ score -= 0
                e "Não, o paciente precisa participar."

    e "Seu placar no quiz foi [score] pontos."

    if score >= 5:
        e "Parabéns! Você completou todas as metas de segurança do paciente."
        e "O Hospital Makiguti deseja te efetivar no setor administrativo!"

    elif score <= -2:
        e "Você não foi bem. Parece que não prestou atenção na Feira de Saúde da Escola Makiguti."

    else:
        scene black
        centered "VOCÊ PERDEU, VOLTE QUANDO ESTUDAR!!!"
    # This ends the game.

    return
